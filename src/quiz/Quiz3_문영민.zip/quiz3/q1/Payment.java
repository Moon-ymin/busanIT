package quiz.quiz3.q1;

public interface Payment {
    void pay(int money);
}
