package quiz.quiz3.q2;

public interface OnClickListener {
    void onClick();
}
